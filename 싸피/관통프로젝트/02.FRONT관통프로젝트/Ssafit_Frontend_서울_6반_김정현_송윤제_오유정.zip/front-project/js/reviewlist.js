window.onload = function () {
  const query = window.location.search;
  const param = new URLSearchParams(query);
  let id = param.get("id");
  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url = "./data/video.json";
  xhr.open(method, url);
  xhr.setRequestHeader("Content-Type", "application/text"); //파라미터 무슨의미??
  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE && xhr.status === 200) {
      const videoList = JSON.parse(xhr.responseText);
      let video = videoList.find((x) => x.id === id); //+붙이면 문자열->숫자 됨
      let details = document.querySelector("#video"); //참조값으로 받아와야 함!!
      details.innerHTML = `
      <iframe
      width="560"
      height="315"
      src="https://www.youtube.com/embed/${video.id}"
      title="YouTube video player"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      allowfullscreen></iframe>
      `;
      register(id);
      reviewLoad(id);
    }
  };
  xhr.send();
};
//버튼 선택후
function register(id) {
  let btn = document.querySelector("#register");
  btn.addEventListener("click", function () {
    //정보 가져오기
    let temptitle = document.querySelector("#title").value;
    let tempcontent = document.querySelector(".modal-body>textarea").value;
    let tempauthor = document.querySelector("#author").value;
    let today = new Date();
    let tempdate =
      today.getFullYear() +
      "/" +
      (today.getMonth() + 1) +
      "/" +
      today.getDate();
    //리뷰 등록
    var review = {
      title: temptitle,
      content: tempcontent,
      author: tempauthor,
      date: tempdate,
    };

    //일단 기존 리뷰 가져옴!!
    var reviews = localStorage.getItem(id);
    if (reviews === null) {
      reviews = new Array();
      reviews.push(review);
    } else {
      reviews = JSON.parse(reviews);
      reviews.push(review);
    }
    localStorage.setItem(id, JSON.stringify(reviews));
    //리뷰 작성한 후 새로고침
    window.location.reload();
  });
}
function reviewLoad(id) {
  //리뷰 뿌려주기!!!
  let board = document.querySelector("#reviews");
  var reviews = localStorage.getItem(id);
  if (reviews !== null) {
    reviews = JSON.parse(reviews);
    for (let i = 0; i < reviews.length; i++) {
      let tr = document.createElement("tr");
      tr.innerHTML += `
      <tr>
      <td>${i + 1}</td>
      <td>
        <a
          href="reviewdetail.html?index=${i}&id=${id}"
          style="text-decoration: none; color: black">
          ${reviews[i].title}
        </a>
      </td>
      <td>${reviews[i].author}</td>
      <td>${reviews[i].date}</td>
      </tr>
      `;
      board.appendChild(tr);
    }
  } else {
    board.innerHTML = "<tr>아직 등록된 리뷰가 없어요.</tr>";
  }
}
