// const URL = "https://www.googleapis.com/youtube/v3/search";
// const API_KEY = "AIzaSyCUsWWuXWEiJVbjbwJZgXFMl7PPkMh9Kgk";
window.onload = function () {
  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url = "./data/video.json";
  xhr.open(method, url);
  xhr.setRequestHeader("Content-Type", "application/text");
  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE && xhr.status === 200) {
      const videoList = JSON.parse(xhr.responseText);
      console.log(videoList);
      let videoListUl = document.querySelector("#videoList");
      for (let i = 0; i < videoList.length; i++) {
        let videoListHTML = `
        <li>
        <img src="https://i.ytimg.com/vi/${videoList[i].id}/maxresdefault.jpg"/>
        <div>
          <div class="title">
          <a href="./reviewlist.html?id=${videoList[i].id}">
            ${videoList[i].title}
          </a>
          </div>
        </div>
        <div>
          <span class="badge rounded-pill text-bg-primary">${videoList[i].part}</span>
          <div class="channelName">${videoList[i].channelName}</div>
        </div>
      </li>
        `;
        videoListUl.innerHTML += videoListHTML;
      }
    }
  };
  xhr.send();
};
// const btn = document.querySelector("검색버튼");
// btn.addEventListener("click", () => {
//   //검색어를 가져오기
//   const inputTag = document.querySelector("검색창");
//   let keyword = inputTag.value;
//   //그 검색어를 fetch를 이용해서 요청하기
//   fetch(
//     `${URL}?key=${API_KEY}&part=snippet&q=${keyword}&type=video&maxResults=20`
//   )
//     .then((response) => response.json())
//     .then((body) => body.items)
//     .then((items) => {
//       //요청받은 결과가 도착하면, 리스트 아이템, img 추가하기
//       const ulTag = document.querySelector("#search-result-list");
//       for (let i = 0; i < items.length; i++) {
//         let liTag = document.createElement("li");
//         let imgTag = document.createElement("img");
//         imgTag.src = items[i].snippet.thumbnails.default.url;
//         liTag.appendChild(imgTag);
//         ulTag.appendChild(liTag);
//       }
//     });
// });
