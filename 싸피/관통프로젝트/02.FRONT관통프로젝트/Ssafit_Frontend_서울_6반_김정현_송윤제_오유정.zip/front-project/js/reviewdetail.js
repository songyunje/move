window.onload = function () {
  const query = window.location.search;
  const param = new URLSearchParams(query);
  let id = param.get("id");
  let index = param.get("index");
  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url = "./data/video.json";
  xhr.open(method, url);
  xhr.setRequestHeader("Content-Type", "application/text"); //파라미터 무슨의미??
  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE && xhr.status === 200) {
      const videoList = JSON.parse(xhr.responseText);
      let video = videoList.find((x) => x.id === id);
      let board = document.querySelector("#videoImg"); //참조값으로 받아와야 함!!
      let url = `https://i.ytimg.com/vi/${id}/maxresdefault.jpg`;
      board.setAttribute("src", url);
      let title = document.getElementById("title");
      let author = document.getElementById("author");
      let date = document.getElementById("date");
      let content = document.getElementById("content");
      title.innerHTML = JSON.parse(localStorage.getItem(id))[index].title;
      author.innerHTML = JSON.parse(localStorage.getItem(id))[index].author;
      date.innerHTML = JSON.parse(localStorage.getItem(id))[index].date;
      content.innerHTML = JSON.parse(localStorage.getItem(id))[index].content;
      //함수 넣는 곳!!!
    }
  };
  xhr.send();
};

// // 후기 삭제
// let deleteBtn = document.querySelector("#delete");
// deleteBtn.addEventListener("click", deleteHandler);

// function deleteHandler(id,index) {
//   // 값을 삭제
//   localStorage.removeItem("data");
// }
