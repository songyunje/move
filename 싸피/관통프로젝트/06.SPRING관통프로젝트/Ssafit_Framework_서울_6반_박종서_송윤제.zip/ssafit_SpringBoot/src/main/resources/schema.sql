create database if not exists springproject;

use springproject;


CREATE TABLE IF NOT EXISTS video (
  `vCode` VARCHAR(30) NOT NULL PRIMARY KEY,
  `viewCnt` INT NOT NULL DEFAULT 0, 
  `title` VARCHAR(300) NOT NULL,
  `part` VARCHAR(30) NOT NULL,
  `channelName` VARCHAR(45) NOT NULL,
  `url` VARCHAR(45) NOT NULL,
  `fileName` VARCHAR(200) NULL,
  `fileUri` VARCHAR(200) NULL
);



CREATE TABLE IF NOT EXISTS `user` (
  `userId` VARCHAR(30) NOT NULL,
  `userName` VARCHAR(45) NOT NULL,
  `userPass` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`userId`));


CREATE TABLE IF NOT EXISTS `review` (
  `reviewId` INT NOT NULL AUTO_INCREMENT,
  `vCode` VARCHAR(30) NOT NULL,
  `writer` VARCHAR(45) NOT NULL,
  `content` VARCHAR(300) NULL,
  PRIMARY KEY (`reviewId`));


INSERT INTO video
VALUES
('v1', 0, '전신 다이어트 최고의 운동', '전신', 'ThankyouBUBU', 'https://www.youtube.com/embed/gMaB-fG4u4g', NULL, NULL),
('v2', 0,'하루 15분! 전신 칼로리 불태우는 다이어트 운동', '전신', 'ThankyouBUBU', 'https://www.youtube.com/embed/swRNeYw1JkY', NULL, NULL),
('v3', 0,'상체 다이어트 최고의 운동 BEST', '상체', 'ThankyouBUBU', 'https://www.youtube.com/embed/54tTYO-vU2E', NULL, NULL),
('v4', 0,'상체비만 다이어트 최고의 운동 [상체 핵매운맛]', '상체', 'ThankyouBUBU', 'https://www.youtube.com/embed/QqqZH3j_vH0', NULL, NULL),
('v5', 0,'하체운동이 중요한 이유', '하체', '김강민', 'https://www.youtube.com/embed/tzN6ypk6Sps', NULL, NULL),
('v6', 0,'저는 하체 식주의자 입니다', '하체', 'GYM종국', 'https://www.youtube.com/embed/u5OgcZdNbMo', NULL, NULL),
('v7', 0,'11자복근 복부 최고의 운동 [복근 핵매운맛]', '복부', 'ThankyouBUBU', 'https://www.youtube.com/embed/PjGcOP-TQPE', NULL, NULL),
('v8', 0,'(Sub)누워서하는 5분 복부운동!!', '복부', 'SomiFit', 'https://www.youtube.com/embed/7TLk7pscICk', NULL, NULL);


INSERT INTO review
VALUES
(1, 'v1', '김싸피','성능이 아주 좋습니다'),
(2, 'v2', '최싸피', '스마트냉장고라 편리합니다.'),
(3, 'v3', '최싸피', '역시 폰은 우주폰이 제일 좋아요~!!');

INSERT INTO user
VALUES
("ssafy", "김싸피", "1234"),
("park", "박종서", "1234"),
("song", "송윤제", "1234");



SELECT * FROM video;
SELECT * FROM review;
SELECT * FROM user;
