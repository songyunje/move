package com.ssafy.ssafit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.ssafit.model.dto.Review;
import com.ssafy.ssafit.model.service.ReviewService;

@RestController
@RequestMapping("/api-review")
@CrossOrigin("*")
public class ReviewRestController {
	
	@Autowired
	ReviewService reviewService;
	
	@GetMapping("/list")
	public ResponseEntity<?> showList(){
		List<Review> list = reviewService.getReviewList();
		try {
			if(list==null || list.isEmpty()) return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<List<Review>>(list,HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/insert")
	public ResponseEntity<?> insertReview(Review review){
		try {
			int result = reviewService.insertReview(review);
			return new ResponseEntity<Integer>(result,HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> updateReview(Review review){
		try {
			int result = reviewService.updateReview(review);
			return new ResponseEntity<Integer>(result,HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping("/detail")
	public ResponseEntity<?> showDetail(int revId){
		Review review = reviewService.reviewDetail(revId);
		try {
			if(review==null) return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			return new ResponseEntity<Review>(review,HttpStatus.OK);
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<?> deleteReview(int revId){
		try {
			int result = reviewService.deleteReview(revId);
			return new ResponseEntity<Integer>(result,HttpStatus.OK); 
		}catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
}
