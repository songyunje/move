package com.ssafy.ssafit.model.dto;

public class Video {

	String vCode;
	String title;
	String part;
	String channelName;
	String url;
	String fileName;
	String fileUri;

	public Video() {
	}

	public String getvCode() {
		return vCode;
	}

	public void setvCode(String vCode) {
		this.vCode = vCode;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPart() {
		return part;
	}

	public void setPart(String part) {
		this.part = part;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileUri() {
		return fileUri;
	}

	public void setFileUri(String fileUri) {
		this.fileUri = fileUri;
	}

	@Override
	public String toString() {
		return "VideoDto [vCode=" + vCode + ", title=" + title + ", part=" + part + ", channelName=" + channelName
				+ ", url=" + url + ", fileName=" + fileName + ", fileUri=" + fileUri + "]";
	}

}
