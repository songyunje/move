package com.ssafy.ssafit.model.dao;

import java.util.List;

import com.ssafy.ssafit.model.dto.Review;

public interface ReviewDao {

	List<Review> getList();
	
	int insert(Review review);
	
	int update(Review review);
	
	Review selectOne(int reivewId);
	
	int delete(int reviewId);
}
