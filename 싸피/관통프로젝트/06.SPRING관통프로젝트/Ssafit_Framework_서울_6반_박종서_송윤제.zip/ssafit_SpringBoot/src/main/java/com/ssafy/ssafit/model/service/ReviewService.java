package com.ssafy.ssafit.model.service;

import java.util.List;

import com.ssafy.ssafit.model.dto.Review;

public interface ReviewService {
	
	List<Review> getReviewList();
	
	int insertReview(Review review);
	
	int updateReview(Review review);
	
	Review reviewDetail(int reivewId);
	
	int deleteReview(int reviewId);
}
