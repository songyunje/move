package com.ssafy.ssafit.model.dto;

public class Review {
	private int id;
	private String vCode;
	private String writer;
	private String content;
	
	public Review() {
	}

	public Review(int id, String vCode, String writer, String content) {
		super();
		this.id = id;
		this.vCode = vCode;
		this.writer = writer;
		this.content = content;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getvCode() {
		return vCode;
	}

	public void setvCode(String vCode) {
		this.vCode = vCode;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
}
