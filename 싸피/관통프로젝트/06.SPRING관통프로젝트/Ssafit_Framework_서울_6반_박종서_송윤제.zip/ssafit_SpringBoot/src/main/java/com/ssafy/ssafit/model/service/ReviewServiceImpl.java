package com.ssafy.ssafit.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.ssafit.model.dao.ReviewDao;
import com.ssafy.ssafit.model.dto.Review;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	ReviewDao reviewDao;
	
	@Override
	public List<Review> getReviewList() {
		return reviewDao.getList();
	}

	@Override
	public int insertReview(Review review) {
		return reviewDao.insert(review);
	}

	@Override
	public int updateReview(Review review) {
		return reviewDao.update(review);
	}

	@Override
	public Review reviewDetail(int reivewId) {
		return reviewDao.selectOne(reivewId);
	}

	@Override
	public int deleteReview(int reviewId) {
		return reviewDao.delete(reviewId);
	}

}
