package com.ssafy.ssafit.model.service;

import com.ssafy.ssafit.model.dto.User;

public interface UserService {
	
	public int signup(User user);
	
	public User login(String id, String password);
}
