package com.ssafy.ssafit.model.dao;

import com.ssafy.ssafit.model.dto.User;

public interface UserDao {
	
	public User selectById(String id);
	
	public int insertUser(User user);
}
