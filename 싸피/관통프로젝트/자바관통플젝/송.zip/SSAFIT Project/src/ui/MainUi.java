package ui;

import java.io.BufferedReader;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Arrays;

import com.google.gson.Gson;

import model.dao.UserData;
import model.dao.UserImpl;
import util.SsafitUtil;

public class MainUi {
	public void service() throws Exception {
//		SsafitUtil.screenClear();
		UserImpl.getInstance().setList(UserData.getInstance().modifyUser());

		SsafitUtil.printLine();
		System.out.println("윤제유정의 SSAFIT");
		System.out.println();
		SsafitUtil.printLine();
		while (true) {
			SsafitUtil.printLine();
			System.out.println("1. 영상정보");
			System.out.println("2. 유저정보");
			System.out.println("0. 종료");
			SsafitUtil.printLine();
			switch (SsafitUtil.input("메뉴를 선택하세요 : ")) {

			case "1": 
				VideoUi.getInstance().service(); 
				break;
			case "2":
				UserUi.getInstance().service();
				break;
			case "0": exit();
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
//			SsafitUtil.screenClear();
		}
	}
	
	private void exit() throws Exception{
		SsafitUtil.printLine();
		System.out.println("시스템을 종료합니다.");
		UserImpl.getInstance().printList();

		System.exit(0);
	}
}
