package ui;

import java.util.List;
import java.util.Scanner;

import model.Video;
import model.dao.VideoDao;
import model.dao.VideoDaoImpl;
import util.SsafitUtil;

public class VideoUi {
	
		private VideoDao videoDao;
		private static VideoUi instance;
		public VideoUi() {
			videoDao = VideoDaoImpl.getInstance();
		}
		public static VideoUi getInstance() {
			if (instance == null)
				instance = new VideoUi();

			return instance;
		}
		
		Scanner sc = new Scanner(System.in);
		
		public void service() throws Exception {
			while(true) {
				SsafitUtil.printLine();
				System.out.println("1.영상목록");
				System.out.println("0.이전으로");
				SsafitUtil.printLine();
				System.out.print("메뉴를 선택하세요 :");
				int msg = sc.nextInt();
				if(msg == 1) {
					listVideo();
				}else if(msg == 0) {
					return;
				}else {
					System.out.println("입력이 잘못되었습니다.");
				}
			
			}
			
		}
		
		private void listVideo() throws Exception {
			
			while(true) {
				
//				SsafitUtil.screenClear();
				SsafitUtil.printLine();
				List<Video> list = videoDao.selectVideo();
				System.out.println("전체 : " +list.size() +"개");
				SsafitUtil.printLine();
				System.out.println("번호 파트  제목");
				//리스트 받아오고
				for(int i = 0; i<list.size(); i++) {
					System.out.println(list.get(i).getNo()+
							"    "+ list.get(i).getPart() + "  " + list.get(i).getTitle());
				}
				
				
				SsafitUtil.printLine();
				System.out.println("1.영상상세");
				System.out.println("0.이전으로");
				SsafitUtil.printLine();
				System.out.print("메뉴를 선택하세요 :");
				int msg = sc.nextInt();
				if(msg == 1) {
					detailVideo();
				}else if(msg == 0) {
					return;
				}else {
					System.out.println("입력이 잘못되었습니다.");
				}
			
			}
			
		}
	
		private void detailVideo() {
			System.out.print("영상번호를 입력하세요 : ");
			int num = sc.nextInt();
			
			try {
				Video video = videoDao.selectVideoByNo(num);
//				SsafitUtil.screenClear();
				SsafitUtil.printLine();
				
				//영상 정보 불러 오고 
				System.out.println("번호 :" + video.getNo());
				System.out.println("제목 : " + video.getTitle());
				System.out.println("운동 : " + video.getPart());
				System.out.println("영상URL : " + video.getUrl());
				SsafitUtil.printLine();
			
				//리뷰 불러오기 
				VideoReviewUi.getInstance(video.getNo()).service();
				
			} catch (Exception e) {
				System.out.println("해당하는 영상이 없습니다.");
				e.printStackTrace();
			}
			
			
			
			
		}
	
	
	
	
}
