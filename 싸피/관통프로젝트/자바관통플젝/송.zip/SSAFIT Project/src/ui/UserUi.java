package ui;

import model.dao.UserImpl;
import util.SsafitUtil;

public class UserUi {
	private static UserUi userUi = new UserUi();
	
	private UserUi() {};
	
	public static UserUi getInstance() {
		return userUi;
	}
	
	
	
	public void service() {
		while (true) {
			SsafitUtil.printLine();
			System.out.println("1. 회원가입");
			System.out.println("2. 회원정보");
			System.out.println("0. 이전으로");
			SsafitUtil.printLine();
			switch (SsafitUtil.input("메뉴를 선택하세요 : ")) {

			case "1": 
				UserImpl.getInstance().addUser();
				break;
			case "2":
				UserImpl.getInstance().showUser();
				break;
			case "0":
				return;
			default:
				System.out.println("입력이 잘못되었습니다.");
			}
		}
	}

}
