package util;

import java.util.Scanner;

public class SsafitUtil {
	private static Scanner sc = new Scanner(System.in);
	
	private SsafitUtil() {};
	
	public static String input(String msg) {
		System.out.print(msg);
		return sc.nextLine();
	}
	
	public static int inputInt(String msg) {
		return Integer.parseInt(input(msg));
	}
	
	public static void printLine() {
		for(int i=0;i<80;i++){
			System.out.print("-");
		}
		System.out.println();
	}
	
//	public static void screenClear() {
//		System.out.print("\033[H\033[2J");
//        System.out.flush();
//	}

}
