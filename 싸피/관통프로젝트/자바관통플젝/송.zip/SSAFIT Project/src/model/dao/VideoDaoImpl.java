package model.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

import model.Video;

public class VideoDaoImpl implements VideoDao {

	private static List<Video> list;
	private static VideoDaoImpl instance;
	
	public VideoDaoImpl() {
		try {
				BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("data/video.json")));
				String str = null;
				StringBuilder sb = new StringBuilder();
				while((str = br.readLine()) != null) {
					sb.append(str).append("\n");
				}
			
			Gson gson = new Gson();
			Video[] arr = gson.fromJson(sb.toString(), Video[].class);
			list = Arrays.asList(arr);
			
		}catch(Exception e) {
			System.out.println("에러가 발생하였습니다.");
			e.printStackTrace();
		}
	
	}
	
	public static VideoDaoImpl getInstance() {
		if(instance == null) {
			instance = new VideoDaoImpl();
		}
		return instance;
		
	}
	
	
	@Override
	public List<Video> selectVideo() throws Exception {
		if (list == null || list.isEmpty()) {
			throw new Exception("영상이 존재하지 않습니다.");
		}
		return list;
	}

	@Override
	public Video selectVideoByNo(int no) throws Exception {
		for(int i = 0 ; i <list.size(); i++) {
			if(list.get(i).getNo() == no ) {
				return list.get(i);
			}
		}
		return null;
	}
	
}
