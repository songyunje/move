package model.dao;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

import model.User;

public class UserData {
	private UserData() {};
	
	private static UserData lg = new UserData();
	
	public static UserData getInstance() {
		return lg;
	}

	
	public List<User> modifyUser() throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream("회원정보.json")));
		String data = br.readLine();
		Gson gson = new Gson();
		User[] list = gson.fromJson(data, User[].class);
		List<User> list2 =  Arrays.asList(list); 
		return list2;
	}
	
	
	
}
