package model.dao;

import java.util.List;

import model.VideoReview;

public interface VideoReviewDao {
	
	int insertReview(VideoReview videoreview);
	
	List<VideoReview> selectReview(int videoNo);
	

}
