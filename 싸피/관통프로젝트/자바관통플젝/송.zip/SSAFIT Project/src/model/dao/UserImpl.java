package model.dao;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

import model.User;
import util.SsafitUtil;

public class UserImpl {
	

	Gson gson = new Gson();
	
	private List<User> userList = new ArrayList<>();

	private UserImpl() {};
	
	private static UserImpl instance = new UserImpl();
	
	public static UserImpl getInstance() {
		return instance;
	}
	
	public void setList(List<User> list){
		userList = list;
	}
	

	public void showUser() {
		for(int i=0;i<userList.size();i++) {
			System.out.println("아이디:   " + userList.get(i).getId()
					+ "비밀번호   " + userList.get(i).getPassword()
					+ "이름   " + userList.get(i).getName()
					+ "이메일   " + userList.get(i).getEmail());
		}
	}

	
	public int addUser() {
		User user = new User();
		user.setId(SsafitUtil.input("아이디를 입력해주세요: "));
		user.setName(SsafitUtil.input("이름을 입력해주세요: "));
		user.setPassword(SsafitUtil.input("비밀번호를 입력해주세요: "));
		user.setEmail(SsafitUtil.input("이메일을 입력해주세요: "));
		
		ArrayList<User> temp = new ArrayList<>();
		for(User u : userList)
			temp.add(u);
		temp.add(user);
		userList = temp;
		
//		userList.add(user);
		
		return 1;
	}
	
	public void  printList() throws Exception{
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("회원정보.json")));
		String str = gson.toJson(userList);
		bw.write(str);
		
		bw.flush();
		bw.close();

	}
	

}
