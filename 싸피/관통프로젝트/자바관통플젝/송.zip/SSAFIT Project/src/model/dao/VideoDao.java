package model.dao;

import java.util.List;

import model.Video;

public interface VideoDao {
	//비디오 고르기
	List<Video> selectVideo() throws Exception ;

	//비디오 상세 보기 
	Video selectVideoByNo(int no) throws Exception;
		
}
