package model.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.VideoReview;

public class VideoReviewDaoImpl implements VideoReviewDao {
	
	
	
	private int reviewNo =0 ;
	
	Map<Integer, List<VideoReview>> videoReviewDb = new HashMap<>();
	
	private static VideoReviewDaoImpl instance = new VideoReviewDaoImpl();
	
	private VideoReviewDaoImpl() {};
	
	public static VideoReviewDaoImpl getInstance() {
		return instance;
	}
	
	
	
	
	@Override
	public int insertReview(VideoReview videoreview) {
		videoreview.setReviewNo(++reviewNo);
		List<VideoReview> list = videoReviewDb.get(videoreview.getVideoNo());
		
		if(list == null) {
			list = new ArrayList<>();
		}
		list.add(videoreview);
		videoReviewDb.put(videoreview.getVideoNo(),  list);
	
		return 1;
	}

	@Override
	public List<VideoReview> selectReview(int videoNo) {
		return videoReviewDb.get(videoNo);
	}


	
	
	
}
