package test;

import ui.MainUi;

public class SsafitApplication {
	public static void main(String[] args) throws Exception {
		MainUi main = new MainUi();
		main.service();
	}
}
