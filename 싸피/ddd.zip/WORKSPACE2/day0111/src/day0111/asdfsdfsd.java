package day0111;

import java.util.Scanner;

public class asdfsdfsd {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int T = sc.nextInt();
		for(int i=1; i<T+1; i++) {
			int maximum = 0;
			for(int j=0; j<10; j++) {
				int num = sc.nextInt();
				maximum = Math.max(maximum, num);
			}
			System.out.println("#"+ i + " " + maximum);
		}
	}

}
