package day0111;

public class HelloWorld {
	// main => ctrl + spacebar
	// sysout => ctrl + spacebar
	// ctrl + F11
	public static void main(String[] args) {
		System.out.println("Hello World");
		System.out.println("Hello Great 9th!");
	}

}
