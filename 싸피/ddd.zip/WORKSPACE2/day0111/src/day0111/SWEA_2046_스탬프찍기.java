package day0111;

import java.util.Scanner;

public class SWEA_2046_스탬프찍기 {
	public static void main(String[] args) {
		// 1. 입력 받기
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		// 2. (입력 받은 숫자의 개수 만큼) 출력하기
		for(int i=0; i<num; i++) {
			System.out.print("#");
		}
	}

}