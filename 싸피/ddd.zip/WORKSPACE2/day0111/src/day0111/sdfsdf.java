package day0111;

import java.util.Scanner;

public class sdfsdf {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		String s = Integer.toString(N);
		int[] array = new int[s.length()];
		int sum = 0;
		for(int i=0;i<s.length();i++) {
			sum += Integer.parseInt(s.substring(i, i+1));
		}
		System.out.println(sum);
	}

}
