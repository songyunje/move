package selenium_practice;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import okio.Options;

public class Jobposting_project {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://job.ssafy.com/job/employmentinfo/employment/employmentList.do");

		WebElement searchInput = driver.findElement(By.cssSelector("#userId"));
		searchInput.sendKeys("adam1229@naver.com");
		WebElement searchInput1 = driver.findElement(By.cssSelector("#userPwd"));
		searchInput1.sendKeys("Tkvlqlqjs12@");
		searchInput1.sendKeys(Keys.ENTER);
		
		WebElement searchInput2 = driver.findElement(By.cssSelector("#currentPwd"));
		searchInput2.sendKeys("Tkvlqlqjs12@");
		searchInput2.sendKeys(Keys.ENTER);
		
		//채용 홈 이동
		WebElement jobbtn = driver.findElement(By.cssSelector("#header > div.hd > div > h1 > a"));
		jobbtn.click();
		
		//지역-서울시 선택
		WebElement regionbtn = driver.findElement(By.cssSelector("#container > div > div.recruit_info > div > div.srh_wrap> div:nth-child(2)"));
		regionbtn.click();	
		WebElement seoulbtn = driver.findElement(By.cssSelector("#container > div > div.recruit_info > div > div.srh_wrap > div:nth-child(2) > div.selectric-items > div > ul > li:nth-child(2)"));
		seoulbtn.click();
		
		//직무 선택-응용SW엔지니어링 선택
		WebElement typebtn = driver.findElement(By.cssSelector("#container > div > div.recruit_info > div > div.srh_wrap > div:nth-child(3) > div.selectric > span"));
		typebtn.click();	
		WebElement appswbtn = driver.findElement(By.cssSelector("#container > div > div.recruit_info > div > div.srh_wrap > div:nth-child(3) > div.selectric-items > div > ul > li:nth-child(12)"));
		appswbtn.click();
		
		//전체 보기
		WebElement showallbtn = driver.findElement(By.cssSelector("#container > div > div.recruit_info > div > div.srh_wrap > a"));
		showallbtn.click();	
		
		//Url 따기
		String pageUrl = driver.getCurrentUrl();
		
		//회사명과 채용 내용 따기
		List<WebElement> namebtns = driver.findElements(By.cssSelector("#container > div > div > div > div.recruit_tbl > ul > li > div.corp_name > div > a"));	
		List<WebElement> topicbtns = driver.findElements(By.cssSelector("#container > div > div > div > div.recruit_tbl > ul > li > div.recruit_subject"));
	
		List<String> list = new ArrayList(); 
		for(int i=0; i<(namebtns.size()) ; i++) {
			list.add("<"+namebtns.get(i).getText()+">");
			list.add(topicbtns.get(i).getText());
			list.add(" ");
		}

		list.add(pageUrl);
		

		//네이버 로그인
		driver.get("https://mail.naver.com/v2/new?type=toMe");
		WebElement searchInput3 = driver.findElement(By.cssSelector("#id"));
		searchInput3.click();
		StringSelection data = new StringSelection("adam1229");
		Clipboard id = Toolkit.getDefaultToolkit().getSystemClipboard();
		id.setContents(data, data);
		searchInput3.sendKeys(Keys.CONTROL,"V");
	
		WebElement searchInput4 = driver.findElement(By.cssSelector("#pw"));
		searchInput4.click();
		StringSelection data2 = new StringSelection("syj12291");
		Clipboard pw = Toolkit.getDefaultToolkit().getSystemClipboard();
		pw.setContents(data2, data2);
		searchInput4.sendKeys(Keys.CONTROL,"V");
		searchInput4.sendKeys(Keys.ENTER);
		
		
		for(String str : list) {
			System.out.println(str);
		}
		
		
//		WebElement searchInput5 = driver.findElement(By.cssSelector("#content > div.contents_area > div > div.mail_write_option.write_to_me > div.mail_write_option_item.subject > div > div.option_area > div"));
//		searchInput5.click();
//		searchInput5.sendKeys("서울시, 응용SW엔지니어링 직무, 채용 정보");
		
		
	

		driver.switchTo().frame("iframe");
		WebElement aa = driver.findElement(By.cssSelector("body > div"));
		aa.sendKeys("aaa");
//		for(String str : list) {	
//		searchInput6.click();
//		searchInput6.sendKeys("제발");
//			searchInput6.sendKeys(str);
//		}
		
	}	

}