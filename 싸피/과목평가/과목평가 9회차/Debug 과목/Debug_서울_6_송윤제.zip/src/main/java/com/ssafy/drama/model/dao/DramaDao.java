package com.ssafy.drama.model.dao;

import java.util.List;

import com.ssafy.drama.model.dto.Drama;

public interface DramaDao {
	
	// 전체 드라마 조회
	public List<Drama> selectAll();
	
	// id로 드라마 조회
	public Drama selectOne(int id);
	
	// 배우 이름으로 드라마 조회
	public List<Drama> selectOne2(String actor);
	
	// 드라마 등록
	public int insertDrama(Drama drama);
	
	// 드라마 삭제 
	public int deleteDrama(int id);
	
	// 드라마 수정
	public int updateDrama(Drama drama);
}
