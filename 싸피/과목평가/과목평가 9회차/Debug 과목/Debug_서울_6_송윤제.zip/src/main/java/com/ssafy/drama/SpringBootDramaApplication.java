package com.ssafy.drama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDramaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDramaApplication.class, args);
	}

}
