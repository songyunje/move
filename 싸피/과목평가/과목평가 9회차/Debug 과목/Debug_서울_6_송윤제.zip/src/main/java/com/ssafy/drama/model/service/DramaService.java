package com.ssafy.drama.model.service;

import java.util.List;

import com.ssafy.drama.model.dto.Drama;

public interface DramaService {
	
	// 모든 드라마 조회
	List<Drama> getDramaList();
	
	// 드라마 작성 
	int writeDrama(Drama drama);
	
	// 드라마 수정
	int modifyDrama(Drama drama);
	
	// 드라마 삭제
	int removeDrama(int id);
	
	// id로 드라마 선택
	Drama getDrama(int id);
	
	// 배우 이름으로 드라마 검색
	List<Drama> getDramas(String actor);
}
