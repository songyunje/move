package com.ssafy.drama.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssafy.drama.model.dto.Drama;
import com.ssafy.drama.model.service.DramaService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api")
//@CrossOrigin("http://127.0.0.1:5500")
@CrossOrigin("*")
public class DramaRestController {
	
	// service 주입
	@Autowired
	private DramaService dramaService;
	
	
	// 드라마 목록 조회
    // 주입한 DramaService를 이용해서 전체 드라마 목록을 가져온다.
	// 이 때 리스트가 없거나 비어있는 경우에는 no_content를 httpstatus로 responseentity를 날려주고 정상적으로 가져온 경우에는 ok를 날린다.
	// 예외 처리도 해준다.
	@GetMapping("/drama")
	public ResponseEntity<?> list(){
		List<Drama> list = dramaService.getDramaList();
		try {
			if(list == null || list.isEmpty()) return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			else return new ResponseEntity<List<Drama>>(list, HttpStatus.OK);
		}catch(Exception e){
			return exceptionHandling(e);
		}
	}
	
	// 드라마 상세 정보
	// pathvariable로 경로에서 변수를 가져온다.
	// 가져온 board가 없을 경우 no_content를 날려주고 정상적으로 가져온 경우에는 ok를 날린다.
	// 예외 처리 해준다.
	@GetMapping("/drama/{id}")
	public ResponseEntity<?> detail(@PathVariable int id){
		Drama drama = dramaService.getDrama(id);
		try {
			if(drama == null) return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			else return new ResponseEntity<Drama>(drama, HttpStatus.OK);
		}catch(Exception e){
			return exceptionHandling(e);
		}
	}
	
	// 드라마 등록
	// 등록한 드라마 수를 int값으로 리턴 받아
	// 실제 드라마가 등록되지 않은 경우(num=0) 실패했다고 날려주고 아닐경우 ok를 날려준다.
	// 예외 처리해준다.
	@PostMapping("/drama")
	public ResponseEntity<?> regist(Drama drama){
		int num = dramaService.writeDrama(drama);
		try {
			if(num == 0) return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
			else return new ResponseEntity<Integer>(num,HttpStatus.OK);
		}catch(Exception e) {
			return exceptionHandling(e);
		}	
	}
	
	// 드라마 삭제
	// 삭제한 드라마 수를 int값으로 리턴 받아
	// 실제 드라마가 삭제되지 않은 경우(num=0) 실패했다고 날려주고 아닐경우 ok를 날려준다.
	// 예외 처리해준다.
	@DeleteMapping("/drama/{id}")
	public ResponseEntity<?> delete(@PathVariable int id){
		int num = dramaService.removeDrama(id);
		try {
			if(num == 0) return new ResponseEntity<Void>(HttpStatus.NOT_ACCEPTABLE);
			else return new ResponseEntity<Integer>(num,HttpStatus.OK);
		}catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	// 드라마 수정
	// 수정한 드라마 수를 int값으로 리턴 받아
	// 실제 드라마가 수정되지 않은 경우(num=0) 실패했다고 날려주고 아닐경우 ok를 날려준다.
	// 예외 처리해준다.
	// JSON 형태로 보낸다.
	@PutMapping("/drama")
	public ResponseEntity<?> update(@RequestBody Drama drama){
		int num = dramaService.modifyDrama(drama);
		try {
			if(num == 0) return new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
			else return new ResponseEntity<Integer>(num,HttpStatus.OK);
		}catch(Exception e) {
			return exceptionHandling(e);
		}
	}
	
	// 배우 이름으로 드라마 검색
	// pathvariable로 경로에서 변수를 가져온다.
	// 가져온 리스트가 없거나 비어 있는 경우 no content 날려주고 아닐 경우 ok를 날린다.
	// 예외 처리 해준다.
	@GetMapping("/drama/search/{actor}")
	public ResponseEntity<?> list(@PathVariable String actor){
		List<Drama> list = dramaService.getDramas(actor);
		try {
			if(list == null || list.isEmpty()) return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
			else return new ResponseEntity<List<Drama>>(list, HttpStatus.OK);
		}catch(Exception e){
			return exceptionHandling(e);
		}
	}	
	
	// 예외 처리 함수
	// 디버깅을 위해 오류에 대한 정보를 출력하고
	// 오류에 대한 메세지를 날린다.
	private ResponseEntity<String> exceptionHandling(Exception e){
		e.getStackTrace();
		return new ResponseEntity<String>(" Sorry!: "+e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
