package com.ssafy.drama.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ssafy.drama.model.dao.DramaDao;
import com.ssafy.drama.model.dto.Drama;

@Service
public class DramaServiceImpl implements DramaService {
	
	
	private DramaDao dramaDao;
	
	// 설정자 방식으로 주입
	@Autowired
	public void setBaordDao(DramaDao dramaDao) {
		this.dramaDao = dramaDao;
	}
	
	@Override
	public List<Drama> getDramaList() {
		return dramaDao.selectAll();
	}

	// 오류에 대비하여 transactional 지시
	@Transactional
	@Override
	public int writeDrama(Drama drama) {
		return dramaDao.insertDrama(drama);
	}

	@Transactional
	@Override
	public int modifyDrama(Drama drama) {
		return dramaDao.updateDrama(drama);
	}

	@Transactional
	@Override
	public int removeDrama(int id) {
		return dramaDao.deleteDrama(id);
	}

	@Override
	public Drama getDrama(int id) {
		return dramaDao.selectOne(id);
	}
	
	@Override
	public List<Drama> getDramas(String actor){
		return dramaDao.selectOne2(actor);
	}
}
