package com.ssafy.drama.config;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@MapperScan(basePackages = "com.ssafy.drama.model.dao")
public class DBConfig {

}
