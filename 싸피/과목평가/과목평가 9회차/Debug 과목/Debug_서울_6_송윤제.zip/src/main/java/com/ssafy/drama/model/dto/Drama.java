package com.ssafy.drama.model.dto;

public class Drama {
	private int id;
	private String title;
	private String screenwriter;
	private String director;
	private String actors;
	
	
	public Drama() {
	}
		
	public Drama(String title, String screenwriter, String director, String actors) {
		super();
		this.title = title;
		this.screenwriter = screenwriter;
		this.director = director;
		this.actors = actors;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getscreenwriter() {
		return screenwriter;
	}

	public void setscreenwriter(String screenwriter) {
		this.screenwriter = screenwriter;
	}

	public String getdirector() {
		return director;
	}

	public void setdirector(String director) {
		this.director = director;
	}

	public String getactors() {
		return actors;
	}

	public void setactors(String actors) {
		this.actors = actors;
	}

	@Override
	public String toString() {
		return "Drama [id=" + id + ", title=" + title + ", screenwriter=" + screenwriter + ", director=" + director
				+ ", actors=" + actors + "]";
	}
}
